create materialized view order_customer_m_view as
SELECT customers.id,
       customers.username,
       customers.first_name,
       customers.last_name
FROM customer.customers;

alter materialized view order_customer_m_view owner to postgres;

