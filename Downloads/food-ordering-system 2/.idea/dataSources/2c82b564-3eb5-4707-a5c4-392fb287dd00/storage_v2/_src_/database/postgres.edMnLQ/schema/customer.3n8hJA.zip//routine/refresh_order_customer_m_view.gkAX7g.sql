create function refresh_order_customer_m_view() returns trigger
    language plpgsql
as
$$
BEGIN
    refresh materialized VIEW customer.order_customer_m_view;
    return null;
END;
$$;

alter function refresh_order_customer_m_view() owner to postgres;

