create function refresh_order_restaurant_m_view() returns trigger
    language plpgsql
as
$$
BEGIN
    refresh materialized VIEW restaurant.order_restaurant_m_view;
    return null;
END;
$$;

alter function refresh_order_restaurant_m_view() owner to postgres;

